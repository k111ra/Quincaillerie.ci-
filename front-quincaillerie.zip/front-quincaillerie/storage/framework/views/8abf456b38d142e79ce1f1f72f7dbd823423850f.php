<?php
    $container = 'container-fluid';
    $containerNav = 'container-fluid';
?>



<?php $__env->startSection('title', 'Categories de produit'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
  <h1>Liste des produits</h1>
  <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary mb-2">Ajouter un produit</a>
  <table class="table">
      <thead>
          <tr>
              <th scope="col">#</th>
              <th scope="col">Nom du produits</th>
              <th scope="col">Image</th>
              <th scope="col">Action</th>
          </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <th scope="row"><?php echo e($product->id); ?></th>
                  <td><?php echo e($product->nom); ?></td>
                  <td><img src="<?php echo e(asset('storage/' . $product->image)); ?>" width="100" alt="<?php echo e($product->nom); ?>"></td>
                  <td>
                      <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                      <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" class="d-inline">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('POST'); ?>
                          <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                      </form>
                  </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\front-quincaillerie\resources\views/admin/products/index.blade.php ENDPATH**/ ?>