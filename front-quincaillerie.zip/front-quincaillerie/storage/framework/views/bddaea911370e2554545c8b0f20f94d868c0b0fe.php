<?php
$container = 'container-fluid';
$containerNav = 'container-fluid';
?>



<?php $__env->startSection('title', 'Categories de produit'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div class="bs-toast toast fade show bg-success" role="alert" aria-live="assertive" aria-atomic="true">
  <div class="toast-header">
    <i class='bx bx-bell me-2'></i>
    <div class="me-auto fw-semibold">Slide</div>
    
    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
  </div>
  <div class="toast-body">
    <?php echo e(session('success')); ?>

  </div>
</div>
<?php endif; ?>

<div class="container">
  <h1>Create New Carousel Item</h1>
  <form action="<?php echo e(route('admin.slider.store')); ?>" method="POST" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="form-group">
          <label for="title">Title</label>
          <input type="text" class="form-control" id="title" name="title" placeholder="Enter title">
      </div>
      <div class="form-group">
          <label for="description">Description</label>
          <textarea class="form-control" id="description" name="description" rows="3"></textarea>
      </div>
      <div class="mb-3">
        <label for="image" class="form-label">Image</label>
        <input class="form-control" type="file" id="image" name="image">
      </div>
      
      <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

<div class="container">
  <h1>Carousels</h1>
  
  <table class="table">
      <thead>
          <tr>
              <th scope="col">#</th>
              <th scope="col">Title</th>
              <th scope="col">Image</th>
              <th scope="col">Action</th>
          </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <th scope="row"><?php echo e($carousel->id); ?></th>
                  <td><?php echo e($carousel->title); ?></td>
                  <td><img src="<?php echo e(asset('storage/' . $carousel->image)); ?>" width="100" alt="<?php echo e($carousel->title); ?>"></td>
                  <td>
                      <a href="<?php echo e(route('admin.slider.edit', $carousel->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                      <form action="<?php echo e(route('admin.slider.destroy', $carousel->id)); ?>" method="POST" class="d-inline">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('POST'); ?>
                          <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                      </form>
                  </td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\front-quincaillerie\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>