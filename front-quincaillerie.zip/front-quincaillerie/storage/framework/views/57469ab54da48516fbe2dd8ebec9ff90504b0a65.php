<?php
$container = 'container-fluid';
$containerNav = 'container-fluid';
?>



<?php $__env->startSection('title', 'Categories de produit'); ?>

<?php $__env->startSection('content'); ?>
<!-- resources/views/categories/index.blade.php -->
<?php if(session('success')): ?>
<div class="bs-toast toast fade show bg-success" role="alert" aria-live="assertive" aria-atomic="true">
  <div class="toast-header">
    <i class='bx bx-bell me-2'></i>
    <div class="me-auto fw-semibold">Categorie</div>
    
    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
  </div>
  <div class="toast-body">
    <?php echo e(session('success')); ?>

  </div>
</div>
<?php endif; ?>

<div class="container">
  <div class="row justify-content-center">
      <div class="col-md-8">
          <div class="card">
              <div class="card-header">Liste des catégories</div>

              <div class="card-body">
                  <table class="table">
                      <thead>
                          <tr>
                              <th>Nom</th>
                              <th>Slug</th>
                              <th>Description</th>
                              <th>Catégorie parent</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($category->name); ?></td>
                                  <td><?php echo e($category->slug); ?></td>
                                  <td><?php echo e($category->description); ?></td>
                                  <td>
                                      <?php if($category->parent): ?>
                                          <?php echo e($category->parent->name); ?>

                                      <?php else: ?>
                                          Pas de parent
                                      <?php endif; ?>
                                  </td>
                                  <td>
                                      <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>">Editer</a>
                                      <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="POST" style="display: inline-block;">
                                          <?php echo csrf_field(); ?>
                                          <?php echo method_field('DELETE'); ?>
                                          <button type="submit" class="btn btn-link">Supprimer</button>
                                      </form>
                                  </td>
                              </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>

                  <div class="mt-4">
                      <h4>Ajouter une catégorie</h4>

                      <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST">
                          <?php echo csrf_field(); ?>

                          <div class="form-group">
                              <label for="name">Nom</label>
                              <input type="text" class="form-control" name="name" id="name" required>
                          </div>


                          <div class="form-group">
                              <label for="description">Description</label>
                              <textarea class="form-control" name="description" id="description" rows="3" required></textarea>
                          </div>

                          <div class="form-group">
                              <label for="parent_id">Catégorie parent</label>
                              <select class="form-control" name="parent_id" id="parent_id">
                                  <option value="">Pas de parent</option>
                                  <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>

                          <button type="submit" class="btn btn-primary">Ajouter</button>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\front-quincaillerie\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>