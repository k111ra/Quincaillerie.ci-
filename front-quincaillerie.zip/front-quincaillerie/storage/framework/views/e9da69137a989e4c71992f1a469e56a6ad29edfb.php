<!-- START REVOLUTION SLIDER -->

<!-- END REVOLUTION SLIDER -->

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-ride="carousel" data-interval="5000" data-pause="hover">
    <ol class="carousel-indicators">
        <?php $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($index); ?>"
                class="<?php echo e($loop->first ? 'active' : ''); ?>"></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
    <div class="carousel-inner">
        <?php $__currentLoopData = $carousels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $carousel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                <img class="d-block w-100" src="<?php echo e(asset('storage/' . $carousel->image)); ?>" alt="Slide">
                <div class="carousel-caption d-none d-md-block">
                    <h5><?php echo e($carousel->title); ?></h5>
                    <p style="color: black;"><?php echo e($carousel->description); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>
<?php /**PATH C:\laragon\www\front-quincaillerie\resources\views/partials/slider.blade.php ENDPATH**/ ?>