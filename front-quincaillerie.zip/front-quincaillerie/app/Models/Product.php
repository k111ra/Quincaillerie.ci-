<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
  use HasFactory;

  protected $fillable = ['nom', 'description', 'prix', 'image'];

  public function category()
  {
    return $this->belongsTo(Category::class);
  }


  public function tags()
  {
    return $this->belongsToMany(Tag::class, 'product_tags');
  }


}
