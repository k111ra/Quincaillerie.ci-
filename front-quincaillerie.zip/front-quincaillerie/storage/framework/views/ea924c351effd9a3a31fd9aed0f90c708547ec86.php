
<?php $__env->startSection('content'); ?>

Dashboard user simple

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\front-quincaillerie\resources\views/user/dashboard.blade.php ENDPATH**/ ?>