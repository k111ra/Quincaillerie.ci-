<?php
$container = 'container-fluid';
$containerNav = 'container-fluid';
?>



<?php $__env->startSection('title', 'Produits'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Ajouter un nouveau produit')); ?></div>

                    <div class="card-body">
                      <form action="<?php echo e(route('admin.products.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div>
                          <label for="nom" class="form-label">Nom :</label>
                          <input type="text" class="form-control" name="nom" id="nom" placeholder="Nom du produit" required>
                        </div>

                        <div>
                          <label for="description" class="form-label">Description :</label>
                          <textarea class="form-control" name="description" id="description" placeholder="Description du produit" required></textarea>
                        </div>

                        <div>
                          <label for="prix" class="form-label">Prix :</label>
                          <input type="number" class="form-control" name="prix" id="prix" placeholder="Prix du produit" required>
                        </div>

                        <div>
                          <label for="image" class="form-label">Image :</label>
                          <input type="file" class="form-control" name="image" id="image" required>
                        </div>

                        <div>
                          <label for="quantite" class="form-label">Quantité :</label>
                          <input type="number" class="form-control" name="quantite" id="quantite" placeholder="Quantité du produit" required>
                        </div>

                        

                        <div>
                          <label for="categorie_id" class="form-label">Catégorie :</label>
                          <select class="form-control" name="categorie_id" id="categorie_id" required>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                        <div>
                          <label for="tags" class="form-label">Tags :</label>
                          <select class="form-control" name="tags[]" id="tags" multiple>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Ajouter</button>
                      </form>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\front-quincaillerie\resources\views/admin/products/create.blade.php ENDPATH**/ ?>